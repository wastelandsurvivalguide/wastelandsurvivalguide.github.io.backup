﻿Vanilla UI Plus (VUI+) is a Fallout 3 & New Vegas mod that greatly 
improves the user interface without compromising the original style. 
It’s been fully developed and polished, but still supported and 
maintained at moddb.com/mods/vanilla-ui-plus.

DEPENDENCIES
------------
Base VUI+ depends on UIO (www.nexusmods.com/newvegas/mods/57174) for
compatibility with overwritten extensions and better performance.

The plugin option depends on the following mods:

* xNVSE (www.github.com/xNVSE/NVSE/releases)
* JIP-LN (www.github.com/jazzisparis/JIP-LN-NVSE/releases)
* JohnnyGuitar (www.github.com/carxt/JohnnyGuitarNVSE/releases)
* YUP (www.nexusmods.com/newvegas/mods/51664?tab=files)

INSTALLATION
------------
Please use one of the following mod managers:

* MO2 (www.github.com/ModOrganizer2/modorganizer/releases)
* NMM (www.github.com/Nexus-Mods/Nexus-Mod-Manager/releases)

YOU MUST INSTALL VUI+ AFTER ANY OTHER UI EXTENSION SUCH AS THE MCM,
oHUD, WMM, PROJECT NEVADA etc. This will allow UIO to properly
link these mods into VUI+ and let you easily uninstall VUI+ later.

Please note that I do not recommend WMM and oHUD; please check out
Stewie’s Tweaks and the HUD Editor instead.

You should also check out the Addons tab at the VUI+ homepage
(moddb.com/mods/vanilla-ui-plus/addons) for compatibility patches.

After installation you may open the Data\Menus\Prefabs\VUI+\ 
settings.xml file with Notepad++ to set additional options.

CUSTOMIZING KEYBINDS
--------------------
Let’s say that you wish to customize the keys for the Quantity menu
to Q for OK and X for Cancel.

First, navigate to the Data\Menus\Prefabs\VUI+\Keybinds folder and
open Quantity.xml with Notepad++. Then make the following changes:

<_PCButton_Q> QM_OKButton </_PCButton_Q>
<_QM_OKButton> Q) </_QM_OKButton>
<_PCButton_X> QM_CancelButton </_PCButton_X>
<_QM_CancelButton> X) </_QM_CancelButton>

You can now save your changes and test the game. If everything goes
well, you can create a small mod with your custom edits, so that
they won’t be overwritten by new VUI+ versions. If you feel that
your edits would appeal to other players, consider publishing.

UNINSTALLATION ISSUES
---------------------
If you receive the “Vanilla UI Plus is overwritten by another mod”
warning after uninstalling VUI+, then reinstall any UI mod such as
the MCM or WMM via right click and “Reinstall”.

SUPPORT
-------
I can only support issues that I can reproduce in a minimal load
order that includes all dependencies as specified above, and one
conflicting mod only.

You can use the forum or the comments at the VUI+ homepage to post 
your issue. I prefer that you use the forum because it’s easier to 
track, but comments allow guest access and I’m OK with that. Please 
try to include a screenshot.

I may ask you to post a link to an archive of your Data\Menus 
folder. This folder doesn’t contain personal data and you can use an 
ephemeral upload service to post your archive.

To get the contents of Data\Menus in MO2, first download and install
7zip. Then open MO2, click on the Executable menu, select Edit, set
a Title, set Binary to C:\Program Files\7-Zip\7zFM.exe, leave Start
In empty, and set Arguments to the game’s Data path. Running 7zip by
this command will allow it to see what your game sees.

CREDITS
-------
VUI+ is dedicated to all users who provided me with useful feedback.
A few names I remember: Ladez, Ermac, Audley, Manan, Genin, Keleigh,
Mortercotic, Bottletopman, Phoenix, Khaileon, Phlunder, HeroinZero,
ThatGodlyFellow, EPDGaffney, Inthegrave, DarianStephens, Jason213,
Emptybell, TempNexis, Ozzyfan, Jake1702, the Icon Guy, StewieAL,
Forty7Years, JustCauseWhyNot, Nehred, Anro and many others I forget!

Big thanks to Amgame for creating a custom texture file for the HUD
elements. These are a great improvement over the blurry vanilla
ones.

Thanks to Sébastien “Red” Caisse for porting the original game’s
font to a high quality truetype version called Fallouty. This font
was included in Van Buren without Red’s knowledge.

The fonts have been converted and optimized with the DC Font
Generator utility (nexusmods.com/fallout3/mods/15231).

Additional font mapping fixes have been made with David Cobb’s
Oblivion Font Editor (nexusmods.com/oblivion/mods/48029).

The idea of a clickable padding around the scrollbar slider was 
taken from PipWare UI by Rebb (nexusmods.com/newvegas/mods/34913).

The ice cream photo in the logo is courtesy of Anthony Cheung 
(pixabay.com/en/users/anthcheung-4679189).

--
Axonis <axonis@yandex.com>, July 2022