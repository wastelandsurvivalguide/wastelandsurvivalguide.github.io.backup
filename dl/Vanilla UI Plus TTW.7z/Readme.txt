﻿
VUI+ - TTW v9.10 by Audley

DO NOT BOTHER AXONIS FOR SUPPORT FOR THIS MOD. IF YOU CHOOSE TO USE THE TTW VERSION YOU AGREE TO
ONLY REQUEST SUPPORT FROM EITHER MYSELF (Audley) OR THE WSG TEAM.

Vanilla UI Plus - TTW is a TTW mod that greatly 
improves the user interface without compromising the original style. 
It’s been fully developed and polished, but still supported and 
maintained.

DEPENDENCIES
------------
Base VUI+ depends on UIO (www.nexusmods.com/newvegas/mods/57174) for
compatibility with overwritten extensions and better performance.

The plugin option depends on the following mods:

* xNVSE (github.com/xNVSE/NVSE/releases)
* JIP-LN (github.com/jazzisparis/JIP-LN-NVSE/releases)
* JohnnyGuitar (github.com/carxt/JohnnyGuitarNVSE/releases)
* YUPTTW (taleoftwowastelands.com/download_ttw)

[Original Axonis Credits Below]

CREDITS
-------
VUI+ is dedicated to all users who provided me with useful feedback.
A few names I remember: Ladez, Ermac, Audley, Manan, Genin, Keleigh,
Mortercotic, Bottletopman, Phoenix, Khaileon, Phlunder, HeroinZero,
ThatGodlyFellow, EPDGaffney, Inthegrave, DarianStephens, Jason213,
Emptybell, TempNexis, Ozzyfan, Jake1702, the Icon Guy, StewieAL,
Forty7Years, JustCauseWhyNot, Nehred, Anro and many others I forget!

Big thanks to Amgame for creating a custom texture file for the HUD
elements. These are a great improvement over the blurry vanilla
ones.

Thanks to Sébastien “Red” Caisse for porting the original game’s
font to a high quality truetype version called Fallouty. This font
was included in Van Buren without Red’s knowledge.

The fonts have been converted and optimized with the DC Font
Generator utility (nexusmods.com/fallout3/mods/15231).

Additional font mapping fixes have been made with David Cobb’s
Oblivion Font Editor (nexusmods.com/oblivion/mods/48029).

The idea of a clickable padding around the scrollbar slider was 
taken from PipWare UI by Rebb (nexusmods.com/newvegas/mods/34913).

The ice cream photo in the logo is courtesy of Anthony Cheung 
(pixabay.com/en/users/anthcheung-4679189).

